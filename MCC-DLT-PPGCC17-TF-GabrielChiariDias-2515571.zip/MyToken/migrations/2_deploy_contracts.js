const MyToken = artifacts.require("MyToken");

module.exports = async function (deployer) {
  const name = "MyToken";       // Nome do token
  const symbol = "MTK";         // Símbolo do token
  const initialSupply = 1000;   // Suprimento inicial reduzido

  await deployer.deploy(MyToken, name, symbol, initialSupply);
};
