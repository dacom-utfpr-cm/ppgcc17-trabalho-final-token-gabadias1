module.exports = {
  networks: {
    // Rede de desenvolvimento usando o Ganache
    development: {
      host: "127.0.0.1",    
      port: 7545,          
      network_id: "*",   
      gas: 10000000,    
      gasPrice: 20000000000 
    },
  },


  compilers: {
    solc: {
      version: "^0.8.28",    
      settings: {
        optimizer: {
          enabled: true,    
          runs: 200        
        }
      }
    }
  },

  contracts_directory: "./contracts",  
  contracts_build_directory: "./build/contracts", 


  mocha: {
    timeout: 100000 
  },
};



